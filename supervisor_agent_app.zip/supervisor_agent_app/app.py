import html
import json
import logging
import os
import uuid
from typing import Any, Dict, List, Optional

import streamlit as st
from databricks.sdk import WorkspaceClient

# ============================================================
# LOGGING & CONFIGURATION
# ============================================================
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

APP_TITLE = "ADH Knowledge Hub"

# Page configuration - centered ChatGPT-like layout
st.set_page_config(
    page_title=APP_TITLE,
    page_icon="🧠",
    layout="centered",
    initial_sidebar_state="expanded",
)

SUGGESTIONS = [
    ("Explain", "What is the ADH Knowledge Hub and how can it assist my team?"),
    ("Find", "Where can I find documentation for our enterprise data platform?"),
    ("Summarize", "Summarize the key Unity Catalog governance policies I should follow."),
    ("Troubleshoot", "How do I troubleshoot a failed Delta Live Tables (DLT) pipeline?"),
]

# ============================================================
# DATABRICKS AGENT CLIENT
# ============================================================
def get_endpoint_name() -> Optional[str]:
    """Retrieve the Databricks model serving endpoint name from environment."""
    return (
        os.getenv("DATABRICKS_MODEL_ENDPOINT")
        or os.getenv("DATABRICKS_SUPERVISOR_AGENT")
        or os.getenv("DATABRICKS_AGENT_ENDPOINT")
    )


def extract_text_from_content(content: Any) -> str:
    """Recursively extract plain text from various Databricks payload formats."""
    if isinstance(content, str):
        return content.strip()

    if isinstance(content, list):
        parts = []
        for item in content:
            text = extract_text_from_content(item)
            if text:
                parts.append(text)
        return "\n".join(parts).strip()

    if isinstance(content, dict):
        if content.get("type") == "output_text" and content.get("text"):
            return str(content["text"]).strip()

        for key in ("text", "content"):
            if key in content:
                text = extract_text_from_content(content[key])
                if text:
                    return text

    return ""


def extract_answer(payload: Any) -> str:
    """Extract final assistant response text from Databricks agent JSON payload."""
    if not isinstance(payload, dict):
        return json.dumps(payload, indent=2, ensure_ascii=False) if payload else "Empty response from agent."

    # 1. Multi-turn Agent output format
    output_items = payload.get("output")
    if isinstance(output_items, list):
        for item in reversed(output_items):
            if not isinstance(item, dict):
                continue
            if item.get("type") == "message" and item.get("role") == "assistant":
                text = extract_text_from_content(item.get("content"))
                if text:
                    return text

    # 2. OpenAI / MLflow Chat Completion format
    if "choices" in payload:
        choices = payload["choices"]
        if isinstance(choices, list):
            for choice in reversed(choices):
                if not isinstance(choice, dict):
                    continue
                message = choice.get("message") or {}
                if isinstance(message, dict):
                    content = extract_text_from_content(message.get("content"))
                    if content:
                        return content
                text = choice.get("text")
                if text:
                    extracted = extract_text_from_content(text)
                    if extracted:
                        return extracted

    # 3. Direct response fields
    for key in ("answer", "output", "reply", "text", "result", "predictions"):
        value = payload.get(key)
        if value is not None:
            if isinstance(value, (dict, list)):
                nested = extract_text_from_content(value)
                if nested:
                    return nested
                return json.dumps(value, indent=2, ensure_ascii=False)
            return str(value)

    # 4. Error response
    if "error" in payload:
        error = payload["error"]
        msg = error.get("message") or error.get("code") if isinstance(error, dict) else str(error)
        raise RuntimeError(f"Databricks Agent Error: {msg}")

    return json.dumps(payload, indent=2, ensure_ascii=False)


def ask_supervisor_agent(question: str) -> str:
    """Send query to Databricks supervisor agent endpoint with clean error handling."""
    endpoint_name = get_endpoint_name()
    if not endpoint_name:
        raise ValueError(
            "Databricks supervisor endpoint is not set. Please set DATABRICKS_MODEL_ENDPOINT in environment."
        )

    payload = {
        "input": [
            {
                "role": "user",
                "content": question,
            }
        ]
    }

    logger.info("Calling Databricks supervisor agent endpoint='%s'", endpoint_name)

    try:
        client = WorkspaceClient()
        response = client.api_client.do(
            "POST",
            f"/serving-endpoints/{endpoint_name}/invocations",
            body=payload,
        )
    except Exception as exc:
        logger.exception("Supervisor agent request failed: %s", exc)
        raise RuntimeError(f"Failed to communicate with Databricks endpoint '{endpoint_name}': {exc}") from exc

    if isinstance(response, dict):
        answer = extract_answer(response)
        return answer or "The Databricks agent returned an empty response. Please review endpoint logs."

    raw_text = getattr(response, "text", "") or str(response)
    try:
        parsed = json.loads(raw_text)
        return extract_answer(parsed)
    except Exception:
        return raw_text if raw_text else "Empty response received from agent."


# ============================================================
# CORRECTED, RESPONSIVE STREAMLIT CSS
# ============================================================
st.markdown(
    """
    <style>
    /* ============================================================
       1. GLOBAL RESET & AUTO-CENTERING
       Fixes left-aligned drift in Databricks Lakehouse App iframes
       ============================================================ */
    #MainMenu, footer { visibility: hidden !important; display: none !important; }

    /* Kill Streamlit default red (rgb(255,75,75)) on any hover/focus everywhere */
    [class*="st-emotion-cache"]:hover,
    [class*="st-emotion-cache"]:focus,
    [class*="st-emotion-cache"]:focus-visible,
    [class*="st-emotion-cache"]:focus-within {
        border-color: inherit !important;
        color: inherit !important;
    }

    /* Frosted top header prevents scroll collisions */
    header[data-testid="stHeader"] {
        background: rgba(255, 255, 255, 0.85) !important;
        backdrop-filter: blur(8px) !important;
        -webkit-backdrop-filter: blur(8px) !important;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05) !important;
        z-index: 99 !important;
    }

    /* Core container centering: margin: 0 auto is essential! */
    .block-container {
        max-width: 52rem !important;
        width: 100% !important;
        margin-left: auto !important;
        margin-right: auto !important;
        padding-left: 1.5rem !important;
        padding-right: 1.5rem !important;
        padding-top: 1.25rem !important;
        padding-bottom: 7.5rem !important;
        box-sizing: border-box !important;
    }

    /* ============================================================
       2. SIDEBAR STYLING
       Scoped properly to avoid breaking icons, text, or expanders
       ============================================================ */
    section[data-testid="stSidebar"] {
        background: #111827 !important;
        border-right: 1px solid #1f2937 !important;
    }
    section[data-testid="stSidebar"] .block-container {
        padding-top: 2rem !important;
        padding-left: 1rem !important;
        padding-right: 1rem !important;
        max-width: 100% !important;
    }

    .sidebar-brand {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        font-size: 1.15rem;
        font-weight: 700;
        color: #f9fafb !important;
        padding: 0.25rem 0.5rem 1.25rem;
        letter-spacing: -0.01em;
    }

    .sidebar-section-title {
        color: #9ca3af !important;
        font-size: 0.72rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        padding: 1.25rem 0.5rem 0.45rem;
    }

    section[data-testid="stSidebar"] .stButton > button {
        width: 100% !important;
        background: #1f2937 !important;
        border: 1px solid #374151 !important;
        color: #f3f4f6 !important;
        justify-content: flex-start !important;
        text-align: left !important;
        padding: 0.55rem 0.85rem !important;
        min-height: 2.35rem !important;
        border-radius: 0.6rem !important;
        font-size: 0.88rem !important;
        font-weight: 500 !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
        transition: all 0.15s ease-in-out !important;
    }
    section[data-testid="stSidebar"] .stButton > button:hover {
        background: #374151 !important;
        border-color: #4b5563 !important;
        color: #ffffff !important;
        transform: translateY(-1px);
    }
    section[data-testid="stSidebar"] .stButton > button[kind="primary"],
    section[data-testid="stSidebar"] [data-testid="stBaseButton-primary"] {
        background: #2563eb !important;
        border-color: #3b82f6 !important;
        color: #ffffff !important;
    }
    section[data-testid="stSidebar"] .stButton > button p {
        margin: 0 !important;
        white-space: nowrap !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        color: inherit !important;
    }

    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.82rem;
        padding: 0.45rem 0.75rem;
        border-radius: 0.5rem;
        background: #1f2937;
        border: 1px solid #374151;
        color: #e5e7eb;
        word-break: break-all;
        margin: 0.25rem 0.5rem;
    }
    .status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        display: inline-block;
    }
    .status-dot-on { background: #10b981; box-shadow: 0 0 8px rgba(16, 185, 129, 0.6); }
    .status-dot-off { background: #f59e0b; box-shadow: 0 0 8px rgba(245, 158, 11, 0.6); }

    /* ============================================================
       3. TOP HEADER & WELCOME SCREEN
       ============================================================ */
    .top-header-bar {
        font-size: 1.1rem;
        font-weight: 700;
        color: #1f2937;
        padding-bottom: 0.75rem;
        margin-bottom: 1.25rem;
        border-bottom: 1px solid #f3f4f6;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .welcome-container {
        text-align: center;
        margin: 10vh auto 2.5rem;
        max-width: 38rem;
    }
    .welcome-icon { font-size: 3.2rem; margin-bottom: 0.75rem; display: inline-block; }
    .welcome-title {
        font-size: 2.1rem;
        font-weight: 700;
        color: #111827;
        letter-spacing: -0.03em;
        margin-bottom: 0.4rem;
    }
    .welcome-subtitle { font-size: 0.98rem; color: #6b7280; line-height: 1.5; }

    /* ============================================================
       4. SUGGESTION CARDS (SCOPED CLEANLY)
       Does not hijack regular buttons in the interface
       ============================================================ */
    .suggestion-card-btn .stButton > button {
        width: 100% !important;
        min-height: 4.8rem !important;
        padding: 0.9rem 1.1rem !important;
        background: #ffffff !important;
        border: 1px solid #e5e7eb !important;
        border-radius: 0.85rem !important;
        text-align: left !important;
        justify-content: flex-start !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.02) !important;
        transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
    }
    .suggestion-card-btn .stButton > button:hover {
        background: #f9fafb !important;
        border-color: #cbd5e1 !important;
        box-shadow: 0 6px 16px rgba(0,0,0,0.06) !important;
        transform: translateY(-2px) !important;
    }
    .suggestion-card-btn .stButton > button p {
        margin: 0 !important;
        color: #374151 !important;
        font-size: 0.88rem !important;
        line-height: 1.45 !important;
    }
    .suggestion-card-btn .stButton > button p strong {
        color: #111827 !important;
        font-size: 0.95rem !important;
        display: block !important;
        margin-bottom: 0.2rem !important;
    }

    /* ============================================================
       5. CHAT MESSAGES & BUBBLES
       Rock-solid User Bubble flush right & Assistant Bubble left
       ============================================================ */
    .user-bubble-wrapper {
        display: flex !important;
        justify-content: flex-end !important;
        width: 100% !important;
        margin: 1rem 0 0.6rem !important;
    }
    .user-bubble-box {
        display: inline-block !important;
        max-width: 78% !important;
        background: #f3f4f6 !important;
        color: #111827 !important;
        border: 1px solid #e5e7eb !important;
        border-radius: 1.35rem 1.35rem 0.3rem 1.35rem !important;
        padding: 0.75rem 1.15rem !important;
        font-size: 0.95rem !important;
        line-height: 1.5 !important;
        word-break: break-word !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.03) !important;
    }

    [data-testid="stChatMessage"] {
        background: transparent !important;
        padding: 0.65rem 0 1rem !important;
        gap: 0.9rem !important;
        border: none !important;
        width: 100% !important;
    }
    [data-testid="stChatMessage"] [data-testid^="stChatMessageAvatar"] {
        width: 2.2rem !important;
        height: 2.2rem !important;
        border-radius: 50% !important;
        background: #f3f4f6 !important;
        border: 1px solid #e5e7eb !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 1.1rem !important;
    }
    [data-testid="stChatMessage"] [data-testid="stChatMessageContent"] {
        color: #1f2937 !important;
        font-size: 0.95rem !important;
        line-height: 1.6 !important;
        padding-top: 0.15rem !important;
    }
    [data-testid="stChatMessage"] [data-testid="stChatMessageContent"] p {
        margin-top: 0 !important;
        margin-bottom: 0.75rem !important;
    }
    [data-testid="stChatMessage"] [data-testid="stChatMessageContent"] p:last-child {
        margin-bottom: 0 !important;
    }

    /* Code Blocks & Tables */
    [data-testid="stChatMessage"] pre {
        background: #1e293b !important;
        color: #f8fafc !important;
        border-radius: 0.65rem !important;
        padding: 1rem !important;
        margin: 0.8rem 0 !important;
        border: 1px solid #334155 !important;
        overflow-x: auto !important;
    }
    [data-testid="stChatMessage"] code {
        background: #f1f5f9 !important;
        color: #0f172a !important;
        padding: 0.15rem 0.4rem !important;
        border-radius: 0.35rem !important;
        font-size: 0.88em !important;
        font-family: ui-monospace, monospace !important;
    }
    [data-testid="stChatMessage"] pre code {
        background: transparent !important;
        color: inherit !important;
        padding: 0 !important;
    }
    [data-testid="stChatMessage"] table {
        width: 100% !important;
        border-collapse: collapse !important;
        margin: 0.85rem 0 !important;
        font-size: 0.9rem !important;
        border-radius: 0.5rem !important;
        overflow: hidden !important;
        border: 1px solid #e2e8f0 !important;
    }
    [data-testid="stChatMessage"] th,
    [data-testid="stChatMessage"] td {
        border: 1px solid #e2e8f0 !important;
        padding: 0.55rem 0.85rem !important;
        text-align: left !important;
    }
    [data-testid="stChatMessage"] th {
        background: #f8fafc !important;
        font-weight: 600 !important;
        color: #0f172a !important;
    }

    /* ============================================================
       6. CHAT INPUT (STATIONARY & FLUSH-CENTERED)
       ============================================================ */
    [data-testid="stBottom"] {
        background: transparent !important;
        background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.95) 40%, rgba(255,255,255,1) 100%) !important;
    }
    [data-testid="stBottomBlockContainer"] {
        max-width: 52rem !important;
        width: 100% !important;
        margin-left: auto !important;
        margin-right: auto !important;
        padding-left: 1.5rem !important;
        padding-right: 1.5rem !important;
        padding-bottom: 1.25rem !important;
        box-sizing: border-box !important;
    }
    [data-testid="stChatInput"] {
        background: #ffffff !important;
        border: 1px solid #d1d5db !important;
        border-radius: 1.75rem !important;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06) !important;
        padding: 0.25rem 0.65rem 0.25rem 1rem !important;
        transition: box-shadow 0.15s ease !important;
        display: block !important;
    }
    [data-testid="stChatInput"]:focus-within,
    [data-testid="stChatInput"]:focus,
    [data-testid="stChatInput"]:hover {
        border: 1px solid #d1d5db !important;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06) !important;
    }

    [data-testid="stChatInput"] textarea {
        color: #111827 !important;
        font-size: 0.96rem !important;
        line-height: 1.5 !important;
        padding: 0.55rem 0.2rem !important;
    }
    [data-testid="stChatInput"] textarea:focus,
    [data-testid="stChatInput"] textarea:focus-visible {
        outline: none !important;
        border: none !important;
        box-shadow: none !important;
    }

    /* Kill BaseWeb textarea wrapper red border on focus */
    [data-testid="stChatInput"] [data-baseweb="textarea"],
    [data-testid="stChatInput"] [data-baseweb="textarea"]:focus,
    [data-testid="stChatInput"] [data-baseweb="textarea"]:focus-within,
    [data-testid="stChatInput"] [data-baseweb="textarea"]:hover,
    [data-testid="stChatInput"] [data-baseweb="textarea"] > div,
    [data-testid="stChatInput"] [data-baseweb="textarea"] > div:focus,
    [data-testid="stChatInput"] [data-baseweb="textarea"] > div:focus-within,
    [data-testid="stChatInput"] [data-baseweb="textarea"] > div:hover,
    [data-testid="stChatInput"] [data-baseweb="textarea"] > div > div,
    [data-testid="stChatInput"] [data-baseweb="textarea"] > div > div:focus,
    [data-testid="stChatInput"] [data-baseweb="textarea"] > div > div:focus-within {
        border: none !important;
        border-color: transparent !important;
        box-shadow: none !important;
        outline: none !important;
        background: transparent !important;
    }

    /* Kill Streamlit's red (rgb(255,75,75)) hover/focus color globally */
    [data-testid="stChatInput"] *:hover,
    [data-testid="stChatInput"] *:focus,
    [data-testid="stChatInput"] *:focus-within,
    [data-testid="stChatInputSubmitButton"]:hover,
    [data-testid="stChatInputSubmitButton"]:focus {
        border-color: transparent !important;
        color: inherit !important;
    }

    [data-testid="stChatInputSubmitButton"] {
        border-radius: 50% !important;
        background: #111827 !important;
        color: #ffffff !important;
        width: 2.25rem !important;
        height: 2.25rem !important;
        margin: auto 0 !important;
        border: none !important;
    }
    [data-testid="stChatInputSubmitButton"]:hover {
        background: #2563eb !important;
        color: #ffffff !important;
        border: none !important;
        border-color: transparent !important;
    }

    /* ============================================================
       7. RESPONSIVE BREAKPOINTS (DATABRICKS EMBED & MOBILE)
       ============================================================ */
    @media (max-width: 768px) {
        .block-container {
            padding-left: 1rem !important;
            padding-right: 1rem !important;
            padding-bottom: 6.5rem !important;
        }
        [data-testid="stBottomBlockContainer"] {
            padding-left: 1rem !important;
            padding-right: 1rem !important;
            padding-bottom: 0.85rem !important;
        }
        .welcome-container { margin-top: 6vh; }
        .welcome-title { font-size: 1.6rem; }
        .user-bubble-box { max-width: 88% !important; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ============================================================
# STATE MANAGEMENT
# ============================================================
def init_session() -> None:
    if "conversations" not in st.session_state:
        st.session_state.conversations = {}
        st.session_state.current_id = None
        new_conversation()


def new_conversation() -> None:
    cid = uuid.uuid4().hex
    st.session_state.conversations[cid] = {
        "title": "New Chat",
        "messages": [],
    }
    st.session_state.current_id = cid


def select_conversation(cid: str) -> None:
    st.session_state.current_id = cid


def clear_all_conversations() -> None:
    st.session_state.conversations = {}
    st.session_state.current_id = None
    new_conversation()


def queue_prompt(prompt_text: str) -> None:
    st.session_state.pending_prompt = prompt_text


init_session()
current_id = st.session_state.current_id
conversation = st.session_state.conversations[current_id]
messages: List[Dict[str, str]] = conversation["messages"]

# ============================================================
# CHAT INPUT
# ============================================================
user_query = st.chat_input(f"Ask {APP_TITLE}...") or st.session_state.pop("pending_prompt", None)

if user_query:
    if not messages:
        conversation["title"] = user_query[:35] + ("…" if len(user_query) > 35 else "")
    messages.append({"role": "user", "content": user_query})

# ============================================================
# SIDEBAR NAVIGATION
# ============================================================
with st.sidebar:
    st.markdown(
        f'<div class="sidebar-brand"><span>🧠</span> {APP_TITLE}</div>',
        unsafe_allow_html=True,
    )

    st.button("✨  New Chat", use_container_width=True, on_click=new_conversation, type="primary")

    history = [
        (cid, conv)
        for cid, conv in st.session_state.conversations.items()
        if conv["messages"]
    ]

    if history:
        st.markdown('<div class="sidebar-section-title">Recent Chats</div>', unsafe_allow_html=True)
        for cid, conv in reversed(history):
            st.button(
                conv["title"],
                key=f"conv_{cid}",
                use_container_width=True,
                type="primary" if cid == current_id else "secondary",
                on_click=select_conversation,
                args=(cid,),
            )
        st.button(
            "🗑️  Clear All History",
            use_container_width=True,
            on_click=clear_all_conversations,
        )

    st.markdown('<div class="sidebar-section-title">Databricks Agent</div>', unsafe_allow_html=True)
    endpoint = get_endpoint_name()
    if endpoint:
        st.markdown(
            f'<div class="status-badge"><span class="status-dot status-dot-on"></span>'
            f'<span>{html.escape(endpoint)}</span></div>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            '<div class="status-badge"><span class="status-dot status-dot-off"></span>'
            '<span>No Endpoint Configured</span></div>',
            unsafe_allow_html=True,
        )

# ============================================================
# MAIN CHAT AREA
# ============================================================
st.markdown(f'<div class="top-header-bar"><span>🧠</span> {APP_TITLE}</div>', unsafe_allow_html=True)

# 1. Welcome Screen with 2x2 Suggestion Cards
if not messages:
    st.markdown(
        """
        <div class="welcome-container">
            <div class="welcome-icon">🧠</div>
            <div class="welcome-title">What can I help you find today?</div>
            <div class="welcome-subtitle">Ask anything about ADH data architecture, Unity Catalog assets, or pipeline troubleshooting.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    cols = st.columns(2)
    for i, (tag, text) in enumerate(SUGGESTIONS):
        with cols[i % 2]:
            st.markdown('<div class="suggestion-card-btn">', unsafe_allow_html=True)
            st.button(
                f"**{tag}**\n\n{text}",
                key=f"sugg_{i}",
                use_container_width=True,
                on_click=queue_prompt,
                args=(text,),
            )
            st.markdown("</div>", unsafe_allow_html=True)

# 2. Render Existing Messages
for msg in messages:
    if msg["role"] == "user":
        escaped_text = html.escape(msg["content"]).replace("\n", "<br>")
        st.markdown(
            f'<div class="user-bubble-wrapper">'
            f'<div class="user-bubble-box">{escaped_text}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )
    else:
        with st.chat_message("assistant", avatar="🧠"):
            st.markdown(msg["content"])

# 3. Process New User Query
if user_query:
    with st.chat_message("assistant", avatar="🧠"):
        try:
            with st.spinner("Analyzing knowledge base..."):
                answer = ask_supervisor_agent(user_query)
            answer = answer or "The Databricks agent returned an empty response."
            st.markdown(answer)
        except Exception as exc:
            logger.exception("Supervisor Agent error")
            answer = "I couldn't reach the Databricks Supervisor Agent."
            st.error(answer)
            with st.expander("Technical details"):
                st.code(str(exc))
    messages.append({"role": "assistant", "content": answer})