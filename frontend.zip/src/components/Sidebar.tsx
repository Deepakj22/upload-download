import type { Conversation } from "../api";

interface Props {
  conversations: Conversation[];
  activeId: string | null;
  email: string;
  profileName: string;
  disabled: boolean;
  onNew: () => void;
  onSelect: (id: string) => void;
  onLogout: () => void;
}

export default function Sidebar({
  conversations,
  activeId,
  email,
  profileName,
  disabled,
  onNew,
  onSelect,
  onLogout,
}: Props) {
  return (
    <aside className="sidebar">
      <a className="brand" href="/" aria-label="Cencora home">
        <img src="/cencora-logo.png" alt="Cencora" />
      </a>
      <button className="new-chat" onClick={onNew} disabled={disabled}>
        + New chat
      </button>

      <nav className="conversation-list">
        {conversations.length === 0 && (
          <p className="muted small">No conversations yet</p>
        )}
        {conversations.map((c) => (
          <button
            key={c.id}
            className={`conversation ${c.id === activeId ? "active" : ""}`}
            title={c.title}
            disabled={disabled}
            onClick={() => onSelect(c.id)}
          >
            {c.title}
          </button>
        ))}
      </nav>

      <div className="account">
        <span className="profile-name" title={profileName}>
          {profileName}
        </span>
        {profileName !== email && (
          <span className="email muted small" title={email}>
            {email}
          </span>
        )}
        <button className="link" onClick={onLogout}>
          Sign out
        </button>
      </div>
    </aside>
  );
}
