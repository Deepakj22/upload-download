import { useEffect, useRef } from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import type { Message } from "../api";

const markdownComponents: Components = {
  a: ({ node: _node, ...props }) => (
    <a {...props} target="_blank" rel="noopener noreferrer" />
  ),
};

interface Props {
  messages: Message[];
  loading: boolean;
  thinking: boolean;
}

export default function MessageList({ messages, loading, thinking }: Props) {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, thinking]);

  return (
    <div className="messages">
      {loading && (
        <div className="muted center-text">Loading conversation…</div>
      )}
      {messages.map((m) => (
        <div key={m.id} className={`message ${m.message_role}`}>
          {m.message_role === "assistant" ? (
            <div className="bubble markdown">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={markdownComponents}
              >
                {m.message}
              </ReactMarkdown>
            </div>
          ) : (
            <div className="bubble">{m.message}</div>
          )}
        </div>
      ))}
      {thinking && (
        <div className="message assistant">
          <div className="bubble muted">Thinking…</div>
        </div>
      )}
      <div ref={endRef} />
    </div>
  );
}
