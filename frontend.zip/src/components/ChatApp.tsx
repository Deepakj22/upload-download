import { useCallback, useEffect, useRef, useState } from "react";
import { useMsal } from "@azure/msal-react";
import {
  api,
  ApiError,
  type Conversation,
  type Message,
  type User,
} from "../api";
import Sidebar from "./Sidebar";
import Composer from "./Composer";
import MessageList from "./MessageList";

const USER_ID_KEY = "adh_user_id";
const USER_EMAIL_KEY = "adh_user_email";
const USER_NAME_KEY = "adh_user_profile_name";

async function resolveUser(accountEmail: string): Promise<User> {
  const cachedId = sessionStorage.getItem(USER_ID_KEY);
  const cachedEmail = sessionStorage.getItem(USER_EMAIL_KEY);
  const cachedName = sessionStorage.getItem(USER_NAME_KEY);
  if (cachedId && cachedEmail && cachedEmail === accountEmail.toLowerCase()) {
    return { id: cachedId, email: cachedEmail, profile_name: cachedName };
  }

  const user = await api.registerCurrentUser();
  sessionStorage.setItem(USER_ID_KEY, user.id);
  sessionStorage.setItem(USER_EMAIL_KEY, user.email);
  sessionStorage.setItem(USER_NAME_KEY, user.profile_name ?? user.email);
  return user;
}

export default function ChatApp() {
  const { instance, accounts } = useMsal();
  const account = instance.getActiveAccount() ?? accounts[0];
  const accountEmail = account?.username;

  const [user, setUser] = useState<User | null>(null);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [accessDenied, setAccessDenied] = useState(false);

  const reportError = (cause: unknown) => {
    if (cause instanceof ApiError && cause.status === 403) {
      setAccessDenied(true);
      setError(null);
      return;
    }
    setError((cause as Error).message);
  };

  // Guards against responses for a conversation the user has navigated away from.
  const activeIdRef = useRef<string | null>(null);
  activeIdRef.current = activeId;

  const loadConversations = useCallback(async (userId: string) => {
    setConversations(await api.getConversations(userId));
  }, []);

  useEffect(() => {
    if (!accountEmail) return;
    let cancelled = false;

    (async () => {
      try {
        const resolved = await resolveUser(accountEmail);
        if (cancelled) return;
        setUser(resolved);
        await loadConversations(resolved.id);
      } catch (e) {
        if (!cancelled) reportError(e);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [accountEmail, loadConversations]);

  const selectConversation = async (conversationId: string) => {
    if (conversationId === activeId) return;
    setActiveId(conversationId);
    setMessages([]);
    setError(null);
    setLoadingMessages(true);
    try {
      const result = await api.getMessages(conversationId);
      if (activeIdRef.current === conversationId) setMessages(result);
    } catch (e) {
      reportError(e);
    } finally {
      setLoadingMessages(false);
    }
  };

  const startNewConversation = () => {
    setActiveId(null);
    setMessages([]);
    setError(null);
  };

  const sendQuestion = async (question: string): Promise<boolean> => {
    if (!user) return false;

    const conversationId = activeId;
    const pending: Message = {
      id: `pending-${Date.now()}`,
      conversation_id: conversationId ?? "",
      message_role: "user",
      message: question,
      adh_created_date: new Date().toISOString(),
    };

    setError(null);
    setSending(true);
    setMessages((prev) => [...prev, pending]);

    try {
      const response = await api.ask(
        user.id,
        question,
        conversationId,
        user.email,
      );
      if (activeIdRef.current !== conversationId) return true;

      setMessages((prev) => [
        ...prev,
        {
          id: `answer-${Date.now()}`,
          conversation_id: response.conversation_id,
          message_role: "assistant",
          message: response.answer,
          adh_created_date: new Date().toISOString(),
        },
      ]);

      if (!conversationId) {
        setActiveId(response.conversation_id);
        await loadConversations(user.id);
      }
      return true;
    } catch (e) {
      setMessages((prev) => prev.filter((m) => m.id !== pending.id));
      reportError(e);
      return false;
    } finally {
      setSending(false);
    }
  };

  const logout = () => {
    sessionStorage.removeItem(USER_ID_KEY);
    sessionStorage.removeItem(USER_EMAIL_KEY);
    sessionStorage.removeItem(USER_NAME_KEY);
    instance.logoutRedirect({ account });
  };

  const isEmpty = !activeId && messages.length === 0;

  if (accessDenied) {
    return (
      <main className="access-denied">
        <section>
          <h1>Access restricted</h1>
          <p>
            Your account isn't assigned to a group with access to this
            application.
          </p>
          <p>Contact your administrator if you think you should have access.</p>
          <button className="primary" onClick={logout}>
            Sign out
          </button>
        </section>
      </main>
    );
  }

  return (
    <div className="layout">
      <Sidebar
        conversations={conversations}
        activeId={activeId}
        email={user?.email ?? account?.username ?? ""}
        profileName={
          user?.profile_name ||
          user?.email ||
          account?.name ||
          account?.username ||
          ""
        }
        disabled={sending}
        onNew={startNewConversation}
        onSelect={selectConversation}
        onLogout={logout}
      />

      <main className="main">
        {!user && !error && <div className="center muted">Signing you in…</div>}

        {user && isEmpty && (
          <div className="center">
            <h2>What would you like to know?</h2>
            <div className="composer-wrapper">
              <Composer disabled={sending} onSend={sendQuestion} autoFocus />
            </div>
          </div>
        )}

        {user && !isEmpty && (
          <>
            <MessageList
              messages={messages}
              loading={loadingMessages}
              thinking={sending}
            />
            <div className="composer-wrapper bottom">
              <Composer
                disabled={sending || loadingMessages}
                onSend={sendQuestion}
                autoFocus
              />
            </div>
          </>
        )}

        {error && <div className="error">{error}</div>}
      </main>
    </div>
  );
}
