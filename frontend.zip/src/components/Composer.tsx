import { useState, type FormEvent, type KeyboardEvent } from "react";
import { SendHorizontal } from "lucide-react";

interface Props {
  disabled: boolean;
  autoFocus?: boolean;
  onSend: (question: string) => Promise<boolean>;
}

export default function Composer({ disabled, autoFocus, onSend }: Props) {
  const [value, setValue] = useState("");

  const submit = async (e?: FormEvent) => {
    e?.preventDefault();
    const question = value.trim();
    if (!question || disabled) return;

    setValue("");
    const ok = await onSend(question);
    if (!ok) setValue(question);
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void submit();
    }
  };

  return (
    <form className="composer" onSubmit={submit}>
      <textarea
        value={value}
        placeholder="Ask a question…"
        rows={1}
        autoFocus={autoFocus}
        disabled={disabled}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={onKeyDown}
      />
      <button
        type="submit"
        className="send-button"
        aria-label="Send message"
        title="Send message"
        disabled={disabled || !value.trim()}
      >
        <SendHorizontal size={21} strokeWidth={2.5} aria-hidden="true" />
      </button>
    </form>
  );
}
