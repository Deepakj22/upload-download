import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useMsal,
} from "@azure/msal-react";
import { InteractionStatus } from "@azure/msal-browser";
import { loginRequest } from "./authConfig";
import ChatApp from "./components/ChatApp";

function Login() {
  const { instance, inProgress } = useMsal();

  return (
    <div className="login">
      <h1>ADH Knowledge</h1>
      <p>Sign in with your organization account to continue.</p>
      <button
        className="primary"
        disabled={inProgress !== InteractionStatus.None}
        onClick={() => instance.loginRedirect(loginRequest)}
      >
        Sign in with Microsoft
      </button>
    </div>
  );
}

export default function App() {
  return (
    <>
      <AuthenticatedTemplate>
        <ChatApp />
      </AuthenticatedTemplate>
      <UnauthenticatedTemplate>
        <Login />
      </UnauthenticatedTemplate>
    </>
  );
}
