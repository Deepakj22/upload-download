import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { EventType, type AuthenticationResult } from "@azure/msal-browser";
import { MsalProvider } from "@azure/msal-react";
import { msalInstance } from "./authConfig";
import App from "./App";
import "./index.css";

await msalInstance.initialize();

const redirectResult = await msalInstance.handleRedirectPromise();
if (redirectResult?.account) {
  msalInstance.setActiveAccount(redirectResult.account);
} else if (!msalInstance.getActiveAccount()) {
  const [firstAccount] = msalInstance.getAllAccounts();
  if (firstAccount) msalInstance.setActiveAccount(firstAccount);
}

msalInstance.addEventCallback((event) => {
  if (event.eventType === EventType.LOGIN_SUCCESS && event.payload) {
    msalInstance.setActiveAccount(
      (event.payload as AuthenticationResult).account,
    );
  }
});

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <MsalProvider instance={msalInstance}>
      <App />
    </MsalProvider>
  </StrictMode>,
);
