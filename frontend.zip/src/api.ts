import { InteractionRequiredAuthError } from "@azure/msal-browser";
import { loginRequest, msalInstance } from "./authConfig";

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8001";

export class ApiError extends Error {
  constructor(message: string, public readonly status: number) {
    super(message);
    this.name = "ApiError";
  }
}

export interface User {
  id: string;
  email: string;
  profile_name: string | null;
}

export interface Conversation {
  id: string;
  user_id: string;
  title: string;
  adh_created_date: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  message_role: "user" | "assistant";
  message: string;
  adh_created_date: string;
}

export interface ChatResponse {
  conversation_id: string;
  title: string;
  answer: string;
}

async function getAccessToken(): Promise<string> {
  const account = msalInstance.getActiveAccount();
  if (!account) {
    throw new Error("Not signed in");
  }

  try {
    const result = await msalInstance.acquireTokenSilent({ ...loginRequest, account });
    return result.accessToken;
  } catch (error) {
    if (error instanceof InteractionRequiredAuthError) {
      await msalInstance.acquireTokenRedirect({ ...loginRequest, account });
    }
    throw error;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = await getAccessToken();
  const response = await fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...init.headers,
    },
  });

  if (!response.ok) {
    let detail = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      if (typeof body?.detail === "string") detail = body.detail;
    } catch {
      // Non-JSON error body; keep default message.
    }
    throw new ApiError(detail, response.status);
  }

  if (response.status === 204) {
    return undefined as T;
  }
  return response.json() as Promise<T>;
}

const id = (value: string) => encodeURIComponent(value);

export const api = {
  registerCurrentUser: () =>
    request<User>("/api/users/me", { method: "POST" }),

  getConversations: (userId: string) =>
    request<Conversation[]>(`/api/users/${id(userId)}/conversations`),

  getMessages: (conversationId: string) =>
    request<Message[]>(`/api/conversations/${id(conversationId)}/messages`),

  ask: (userId: string, question: string, conversationId: string | null, createdBy: string) =>
    request<ChatResponse>(`/api/users/${id(userId)}/chat`, {
      method: "POST",
      body: JSON.stringify({
        question,
        conversation_id: conversationId,
        adh_created_by: createdBy,
      }),
    }),
};
