
import {
  PublicClientApplication,
  type Configuration,
} from "@azure/msal-browser";

const tenantId = import.meta.env.VITE_ENTRA_TENANT_ID;
const clientId = import.meta.env.VITE_ENTRA_CLIENT_ID;

if (!tenantId || !clientId) {
  throw new Error("Missing Microsoft Entra environment variables");
}

const msalConfig: Configuration = {
  auth: {
    clientId,
    authority: `https://login.microsoftonline.com/${tenantId}`,
    redirectUri: window.location.origin,
  },
  cache: {
    cacheLocation: "sessionStorage",
  },
};

export const msalInstance = new PublicClientApplication(msalConfig);

export const apiScope: string =
  import.meta.env.VITE_ENTRA_API_SCOPE;
