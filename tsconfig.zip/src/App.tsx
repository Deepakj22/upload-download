import { useState } from "react";
import { useMsal, useIsAuthenticated } from "@azure/msal-react";
import { InteractionStatus } from "@azure/msal-browser";
import axios from "axios";
import { apiScope } from "./authConfig";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
});

export default function App() {
  const { instance, accounts, inProgress } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  const [result, setResult] = useState<unknown>(null);
  const [error, setError] = useState("");

  const account = instance.getActiveAccount() ?? accounts[0];

  async function login() {
    await instance.loginRedirect({
      scopes: [apiScope],
    });
  }

  async function callProtectedApi() {
    setError("");
    setResult(null);

    try {
      if (!account) {
        throw new Error("Please sign in first.");
      }

      const token = await instance.acquireTokenSilent({
        scopes: [apiScope],
        account,
      });

      const response = await api.get("/protected", {
        headers: {
          Authorization: `Bearer ${token.accessToken}`,
        },
      });

      setResult(response.data);
    } catch (err: any) {
      setError(
        err.response?.data?.detail?.message ??
          err.response?.data?.detail ??
          err.message ??
          "API request failed",
      );
    }
  }

  if (inProgress !== InteractionStatus.None) {
    return <p>Loading authentication...</p>;
  }

  return (
    <main style={{ maxWidth: 800, margin: "60px auto", padding: 24 }}>
      <h1>ADH Knowledge Hub</h1>
      <p>React + FastAPI + PostgreSQL + Microsoft Entra ID</p>

      {!isAuthenticated ? (
        <button onClick={login}>Sign in with Microsoft</button>
      ) : (
        <>
          <p>Signed in as: {account?.username}</p>

          <button onClick={callProtectedApi}>Test Protected API</button>

          <button
            onClick={() => instance.logoutRedirect({ account })}
            style={{ marginLeft: 12 }}
          >
            Sign out
          </button>
        </>
      )}

      {result != null && <pre>{JSON.stringify(result, null, 2)}</pre>}

      {error && <p style={{ color: "red" }}>{error}</p>}
    </main>
  );
}
