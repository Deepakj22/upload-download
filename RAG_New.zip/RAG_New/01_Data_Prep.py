# Databricks notebook source
# MAGIC %pip install numpy==1.26.4 openai==1.69.0 langchain-community==0.4.1 PyPDF2==3.0.1

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from PyPDF2 import PdfReader

def perform_fixed_size_chunking(document, chunk_size=2000, chunk_overlap=500):
    """
    Performs recursive chunking on a document with specified overlap.
    Uses RecursiveCharacterTextSplitter which tries multiple separators.
    """
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", ". ", " ", ""]
    )
    return text_splitter.split_text(document)

import os

docs_folder = "./knowledge/docs"
# Unity Catalog Volume path
docs_folder = "/Volumes/workspace/adh_knowledge_rag/knowledge_assistant/pdf"

all_docs = []

# Loop through all files in the Volume
for filename in os.listdir(docs_folder):

    file_path = os.path.join(docs_folder, filename)

    # Process only PDF files
    if os.path.isfile(file_path) and filename.lower().endswith(".pdf"):

        print(f"Processing PDF: {filename}")

        try:
            # Read PDF directly from Unity Catalog Volume
            reader = PdfReader(file_path)

            text = ""

            # Extract text from every page
            for page_num, page in enumerate(reader.pages, start=1):
                page_text = page.extract_text()

                if page_text:
                    text += page_text + "\n"

            # Create chunks from extracted text
            if text.strip():
                chunks = perform_fixed_size_chunking(text)

                for i, chunk in enumerate(chunks):
                    if chunk.strip():
                        all_docs.append({
                            "content_path": file_path,
                            "filename": filename,
                            "chunk_id": i,
                            "chunk": chunk
                        })

                print(f"  Extracted pages: {len(reader.pages)}")
                print(f"  Created chunks: {len(chunks)}")

            else:
                print(f"  No extractable text found: {filename}")

        except Exception as e:
            print(f"  Error processing {filename}: {e}")

# Create Spark DataFrame
if all_docs:
    df = spark.createDataFrame(all_docs)

    print(f"\nTotal chunks created: {df.count()}")

    print("\nChunks per document:")
    df.groupBy("content_path").count().show(truncate=False)

    display(df)

else:
    print("No chunks extracted from documents.")

# COMMAND ----------

df.write.mode("overwrite").saveAsTable("adh_knowledge_rag.pdf_chunks")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM adh_knowledge_rag.pdf_chunks

# COMMAND ----------

spark.sql("""
CREATE OR REPLACE TABLE adh_knowledge_rag.final_rag_dataset AS
SELECT monotonically_increasing_id() AS id, content_path, chunk FROM adh_knowledge_rag.pdf_chunks
""")

display(spark.table("adh_knowledge_rag.final_rag_dataset"))