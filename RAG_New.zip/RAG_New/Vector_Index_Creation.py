# Databricks notebook source
# MAGIC %pip install databricks-vectorsearch==0.63

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# Enable change data feed for the existing Delta table
spark.sql("""
ALTER TABLE workspace.adh_knowledge_rag.final_rag_dataset
SET TBLPROPERTIES (delta.enableChangeDataFeed = true)
""")

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient

vector_client = VectorSearchClient()

# Create endpoint if it doesn't already exist
try:
    vector_client.create_endpoint(
        name="vector_search_endpoint",
        endpoint_type="STANDARD"
    )
except Exception as e:
    if "ALREADY_EXISTS" not in str(e):
        raise

# Create index if it doesn't already exist, otherwise get the existing one
try:
    index = vector_client.create_delta_sync_index(
        endpoint_name="vector_search_endpoint",
        source_table_name="workspace.adh_knowledge_rag.final_rag_dataset",
        index_name="workspace.adh_knowledge_rag.rag_vector_index",
        pipeline_type="TRIGGERED",
        primary_key="id",
        embedding_source_column="chunk",
        embedding_model_endpoint_name="databricks-gte-large-en"
    )
except Exception as e:
    if "ALREADY_EXISTS" not in str(e):
        raise
    index = vector_client.get_index(
        endpoint_name="vector_search_endpoint",
        index_name="workspace.adh_knowledge_rag.rag_vector_index"
    )

# COMMAND ----------

import json
import time

user_question = "CarbonOps ESG Intelligence Model"

results_dict = index.similarity_search(
            query_text = user_question,
            columns = ["content_path", "chunk"],
            num_results=10,
          )

for content in results_dict['result']['data_array']:
    print(json.dumps(content, indent=2, ensure_ascii=False))