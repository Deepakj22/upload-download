from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from database import get_db
from schemas import UserCreate, UserResponse
from services.user_service import UserService

router = APIRouter(prefix="/api/users", tags=["Users"])
service = UserService()


@router.post(
    "",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_user(data: UserCreate, db: Session = Depends(get_db)):
    try:
        return service.create_user(
            db,
            str(data.email),
            data.adh_created_by,
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except IntegrityError:
        raise HTTPException(status_code=409, detail="Email already exists")


@router.get("", response_model=list[UserResponse])
def get_users(db: Session = Depends(get_db)):
    return service.get_users(db)