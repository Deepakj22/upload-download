from sqlalchemy.orm import Session

from data.user_repository import UserRepository
from models import User


class UserService:

    def __init__(self):
        self.repository = UserRepository()

    def create_user(self, db: Session, email: str, created_by=None):
        email = email.strip().lower()

        if self.repository.get_by_email(db, email):
            raise ValueError("User email already exists")

        user = User(
            email=email,
            adh_created_by=created_by,
        )

        try:
            self.repository.create(db, user)
            db.commit()
            db.refresh(user)
            return user
        except Exception:
            db.rollback()
            raise

    def get_users(self, db: Session):
        return self.repository.get_all(db)