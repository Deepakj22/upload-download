import os

from dotenv import load_dotenv
from fastapi_azure_auth.auth import (
    SingleTenantAzureAuthorizationCodeBearer,
)

load_dotenv()

TENANT_ID = os.environ["ENTRA_TENANT_ID"]
CLIENT_ID = os.environ["ENTRA_API_CLIENT_ID"]

API_SCOPE = f"api://{CLIENT_ID}/access_as_user"

# azure_scheme = SingleTenantAzureAuthorizationCodeBearer(
#     app_client_id=CLIENT_ID,
#     tenant_id=TENANT_ID,
#     scopes={
#         API_SCOPE: "Access ADH Knowledge API",
#     },
# )
azure_scheme = SingleTenantAzureAuthorizationCodeBearer(
    app_client_id=CLIENT_ID,
    tenant_id=TENANT_ID,
    scopes={
        f"api://{CLIENT_ID}/access_as_user": "Access ADH Knowledge API",
    },
)