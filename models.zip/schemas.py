
from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field


# =========================================
# Base schema
# =========================================
class ORMBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# =========================================
# Users
# =========================================
class UserCreate(BaseModel):
    email: EmailStr
    adh_created_by: str | None = None


class UserResponse(ORMBase):
    id: UUID
    email: EmailStr
    adh_created_date: datetime
    adh_created_by: str | None = None
    adh_updated_date: datetime | None = None
    adh_updated_by: str | None = None


# =========================================
# Conversations
# =========================================
class ConversationCreate(BaseModel):
    title: str = Field(min_length=1, max_length=500)
    adh_created_by: str | None = None


class ConversationResponse(ORMBase):
    id: UUID
    user_id: UUID
    title: str
    adh_created_date: datetime
    adh_created_by: str | None = None
    adh_updated_date: datetime | None = None
    adh_updated_by: str | None = None


# =========================================
# Messages
# =========================================
class MessageCreate(BaseModel):
    message_role: Literal["user", "assistant"]
    message: str = Field(min_length=1)
    adh_created_by: str | None = None


class MessageResponse(ORMBase):
    id: UUID
    conversation_id: UUID
    message_role: Literal["user", "assistant"]
    message: str
    adh_created_date: datetime
    adh_created_by: str | None = None
    adh_updated_date: datetime | None = None
    adh_updated_by: str | None = None
