from fastapi import FastAPI

from api.users import router as users_router
from api.conversations import router as conversations_router
from api.messages import router as messages_router
from contextlib import asynccontextmanager
from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, Security
from auth import azure_scheme, API_SCOPE, CLIENT_ID

@asynccontextmanager
async def lifespan(app: FastAPI):
    await azure_scheme.openid_config.load_config()
    yield

app = FastAPI(
    title="ADH Knowledge API",
    lifespan=lifespan,
    swagger_ui_oauth2_redirect_url="/oauth2-redirect",
    swagger_ui_init_oauth={
        "usePkceWithAuthorizationCodeGrant": True,
        "clientId": CLIENT_ID,
    },
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
@app.get("/public")
async def public_endpoint():
    return {"message": "Public endpoint working"}

@app.get("/protected")
async def protected_endpoint(
    user=Security(azure_scheme, scopes=["access_as_user"]),
):
    return {
        "message": "Entra ID authentication successful",
        "user": user,
    }


app.include_router(
    users_router,
    dependencies=[Security(azure_scheme, scopes=["access_as_user"])],
                   )
app.include_router(
    conversations_router,
    dependencies=[Security(azure_scheme, scopes=["access_as_user"])],
    )
app.include_router(
    messages_router,
    dependencies=[Security(azure_scheme, scopes=["access_as_user"])],
    )


@app.get("/")
def health_check():
    return {"status": "healthy"}