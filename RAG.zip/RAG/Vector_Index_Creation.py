# Databricks notebook source
# MAGIC %md
# MAGIC ## Databricks Mosaic AI Vector Index Creation

# COMMAND ----------

# MAGIC %md
# MAGIC ![vector_index](./Assets/vector_index.png)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Installing Utilities and Libraries

# COMMAND ----------

# MAGIC %pip install databricks-vectorsearch==0.63

# COMMAND ----------

# MAGIC %md
# MAGIC ### Restarting the Python Kernel

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Enabling CDC (Change Data Capture) on RAG Table in Unity Catalog

# COMMAND ----------

# Enable change data feed for the existing Delta table
spark.sql("""
ALTER TABLE workspace.RAG.final_rag_dataset
SET TBLPROPERTIES (delta.enableChangeDataFeed = true)
""")
     

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating Vector Index and Endpoint

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient

vector_client = VectorSearchClient()

# To recreate the endpoint after deletion:
vector_client.create_endpoint(
     name="vector_search_endpoint",
     endpoint_type="STANDARD"
 )


index = vector_client.create_delta_sync_index(
   endpoint_name="vector_search_endpoint",
   source_table_name="workspace.rag.final_rag_dataset",
   index_name="workspace.rag.rag_vector_index",
   pipeline_type="TRIGGERED",
   primary_key="id",
   embedding_source_column="chunk",
   embedding_model_endpoint_name="databricks-gte-large-en"
  )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Triggering our Index - Information Retrieval

# COMMAND ----------

# MAGIC %md
# MAGIC #### Dense Vector Similarity Search

# COMMAND ----------

# DBTITLE 1,Dense Vector Similarity Search
import json
import time

user_question = "CarbonOps ESG Intelligence Model"

# Check if the index is ready before querying
index_info = index.describe()
print(f"Index status: {json.dumps(index_info, indent=2, ensure_ascii=False)}")

# The index was created with pipeline_type="TRIGGERED", so it needs a manual sync.
# Trigger a sync and wait for the index to become ready.
if not index_info.get('status', {}).get('ready', False):
    print("\nIndex is not ready. Triggering a sync...")
    try:
        index.sync()
        print("Sync triggered. Waiting for index to become ready...")
    except Exception as e:
        print(f"Sync trigger note: {e}")

    max_wait_seconds = 600
    waited = 0
    while waited < max_wait_seconds:
        time.sleep(30)
        waited += 30
        index_info = index.describe()
        ready = index_info.get('status', {}).get('ready', False)
        msg = index_info.get('status', {}).get('message', '')
        indexed_rows = index_info.get('status', {}).get('indexed_row_count', 0)
        print(f"  [{waited}s] ready={ready} | indexed_rows={indexed_rows} | message={msg}")
        if ready:
            break

    if not index_info.get('status', {}).get('ready', False):
        raise RuntimeError(
            f"Index is still not ready after waiting {max_wait_seconds}s. "
            f"Status: {index_info.get('status', {})}"
        )

    print("\nIndex is now ready! Proceeding with similarity search...\n")

results_dict = index.similarity_search(
            query_text = user_question,
            columns = ["content_path", "chunk"],
            num_results=10,
          )

for content in results_dict['result']['data_array']:
    print(json.dumps(content, indent=2, ensure_ascii=False))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Hybrid Search

# COMMAND ----------

user_question = "CarbonOps ESG Intelligence Model"

results_dict = index.similarity_search(
            query_text = "{user_question}",
            columns = ["content_path","chunk"],
            num_results=10,
            query_type="hybrid"
          )

for content in results_dict['result']['data_array']:
    print(json.dumps(content, indent=2, ensure_ascii=False))

# COMMAND ----------

# MAGIC %md
# MAGIC #### ANN (Approximate Nearest Neighbour) Search

# COMMAND ----------

user_question = "CarbonOps ESG Intelligence Model"

results_dict = index.similarity_search(
            query_text = "{user_question}",
            columns = ["content_path", "chunk"],
            num_results=10,
            query_type="ANN"
          )

for content in results_dict['result']['data_array']:
    print(json.dumps(content, indent=2, ensure_ascii=False))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Searching with Semantic Reranker

# COMMAND ----------

from databricks.vector_search.reranker import DatabricksReranker

user_question = "carbonops Sustainable Development Goals Mappings"

results_dict = index.similarity_search(
            query_text = "{user_question}",
            columns = ["content_path", "chunk"],
            num_results=10,
            query_type="hybrid",
            reranker = DatabricksReranker(columns_to_rerank=["chunk", "content_path"])
          )

for content in results_dict['result']['data_array']:
    print(json.dumps(content, indent=2, ensure_ascii=False))