# Databricks notebook source
# MAGIC %md
# MAGIC ## Using Databricks Vector Embedding Engines - OpenAI API and SQL

# COMMAND ----------

# MAGIC %md
# MAGIC ### Installing Libraries and Utilities

# COMMAND ----------

!pip install openai==1.69.0

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating an OpenAI Client

# COMMAND ----------

from openai import OpenAI

client = OpenAI(
    api_key = "YOUR_DATABRICKS_ACCESS_TOKEN",
    base_url = "YOUR_DATABRICKS_WORKSPACE_HOSTNAME/serving-endpoints"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Throwing a Request via the OpenAI API

# COMMAND ----------

# OpenAI Request
completion = client.embeddings.create(
    model="databricks-gte-large-en",
    input="hi how are you?"
)

print("length \n")
print(len(completion.data[0].embedding))
print("\n embeddings: \n")
print(completion.data[0].embedding)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Throwing Request via SQL Query

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT ai_query(
# MAGIC     "databricks-gte-large-en",
# MAGIC     "Can you explain AI in ten words?"
# MAGIC   )