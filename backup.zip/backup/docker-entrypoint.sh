#!/bin/sh
set -eu

: "${VITE_ENTRA_CLIENT_ID:?VITE_ENTRA_CLIENT_ID must be set}"
: "${VITE_ENTRA_TENANT_ID:?VITE_ENTRA_TENANT_ID must be set}"
: "${VITE_API_SCOPE:?VITE_API_SCOPE must be set}"
: "${VITE_API_BASE_URL:?VITE_API_BASE_URL must be set}"

mkdir -p /tmp/client_temp /tmp/proxy_temp /tmp/fastcgi_temp /tmp/uwsgi_temp /tmp/scgi_temp

config="$(jq -n \
  --arg clientId "$VITE_ENTRA_CLIENT_ID" \
  --arg tenantId "$VITE_ENTRA_TENANT_ID" \
  --arg apiScope "$VITE_API_SCOPE" \
  --arg apiBaseUrl "$VITE_API_BASE_URL" \
  '{
    VITE_ENTRA_CLIENT_ID: $clientId,
    VITE_ENTRA_TENANT_ID: $tenantId,
    VITE_API_SCOPE: $apiScope,
    VITE_API_BASE_URL: $apiBaseUrl
  }')"

printf 'window.__APP_CONFIG__ = %s;\n' "$config" \
  > /tmp/runtime-config.js

exec nginx -g 'daemon off;'
