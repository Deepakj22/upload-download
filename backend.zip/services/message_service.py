from uuid import UUID

from sqlalchemy.orm import Session

from data.conversation_repository import ConversationRepository
from data.message_repository import MessageRepository
from models import Message


class MessageService:

    def __init__(self):
        self.conversations = ConversationRepository()
        self.repository = MessageRepository()

    def create_message(
        self,
        db: Session,
        conversation_id: UUID,
        role: str,
        content: str,
        created_by=None,
    ):
        if not self.conversations.get_by_id(db, conversation_id):
            raise LookupError("Conversation not found")

        if role not in ("user", "assistant"):
            raise ValueError("Role must be user or assistant")

        if not content.strip():
            raise ValueError("Message cannot be empty")

        message = Message(
            conversation_id=conversation_id,
            message_role=role,
            message=content,
            adh_created_by=created_by,
        )

        try:
            self.repository.create(db, message)
            db.commit()
            db.refresh(message)
            return message
        except Exception:
            db.rollback()
            raise

    def get_messages(self, db: Session, conversation_id: UUID):
        if not self.conversations.get_by_id(db, conversation_id):
            raise LookupError("Conversation not found")

        return self.repository.get_by_conversation(db, conversation_id)