from uuid import UUID

from sqlalchemy.orm import Session

from data.user_repository import UserRepository
from data.conversation_repository import ConversationRepository
from models import Conversation


class ConversationService:

    def __init__(self):
        self.users = UserRepository()
        self.repository = ConversationRepository()

    def create_conversation(
        self,
        db: Session,
        user_id: UUID,
        title: str,
        created_by=None,
    ):
        if not self.users.get_by_id(db, user_id):
            raise LookupError("User not found")

        title = title.strip()
        if not title:
            raise ValueError("Conversation title is required")

        conversation = Conversation(
            user_id=user_id,
            title=title,
            adh_created_by=created_by,
        )

        try:
            self.repository.create(db, conversation)
            db.commit()
            db.refresh(conversation)
            return conversation
        except Exception:
            db.rollback()
            raise

    def get_conversations(self, db: Session, user_id: UUID):
        if not self.users.get_by_id(db, user_id):
            raise LookupError("User not found")

        return self.repository.get_by_user(db, user_id)

    def delete_conversation(self, db: Session, conversation_id: UUID):
        conversation = self.repository.get_by_id(db, conversation_id)

        if not conversation:
            raise LookupError("Conversation not found")

        try:
            self.repository.delete(db, conversation)
            db.commit()
        except Exception:
            db.rollback()
            raise