from datetime import datetime, timezone

from sqlalchemy.orm import Session

from data.user_repository import UserRepository
from models import User

PROFILE_NAME_MAX_LENGTH = 255


def _profile_name(profile_name: str | None, email: str) -> str:
    name = (profile_name or "").strip() or email
    return name[:PROFILE_NAME_MAX_LENGTH]


class UserService:

    def __init__(self):
        self.repository = UserRepository()

    def create_user(
        self,
        db: Session,
        email: str,
        created_by=None,
        profile_name: str | None = None,
    ):
        email = email.strip().lower()

        if self.repository.get_by_email(db, email):
            raise ValueError("User email already exists")

        user = User(
            email=email,
            profile_name=_profile_name(profile_name, email),
            adh_created_by=created_by,
        )

        try:
            self.repository.create(db, user)
            db.commit()
            db.refresh(user)
            return user
        except Exception:
            db.rollback()
            raise

    def get_users(self, db: Session):
        return self.repository.get_all(db)

    def get_or_create_user(
        self,
        db: Session,
        email: str,
        created_by=None,
        profile_name: str | None = None,
    ):
        email = email.strip().lower()
        if not email:
            raise ValueError("Email is required")

        user = self.repository.get_by_email(db, email)
        if not user:
            return self.create_user(db, email, created_by, profile_name)

        # Keep the stored name in sync with Entra.
        name = _profile_name(profile_name, email)
        if user.profile_name != name:
            user.profile_name = name
            user.adh_updated_date = datetime.now(timezone.utc)
            user.adh_updated_by = created_by
            try:
                db.commit()
                db.refresh(user)
            except Exception:
                db.rollback()
                raise

        return user