from datetime import datetime, timezone
from uuid import UUID

from sqlalchemy.orm import Session

from data.conversation_repository import ConversationRepository
from data.llm_client import LLMClient, LLMServiceError
from data.message_repository import MessageRepository
from data.user_repository import UserRepository
from models import Conversation, Message

HISTORY_LIMIT = 10
TITLE_MAX_LENGTH = 500

TITLE_PROMPT = (
    "Generate a short, descriptive title (max 8 words) for a conversation "
    "that starts with the following question. Respond with the title only, "
    "without quotes or punctuation at the end."
)


class ChatService:

    def __init__(self):
        self.users = UserRepository()
        self.conversations = ConversationRepository()
        self.messages = MessageRepository()
        self.llm = LLMClient()

    def ask(
        self,
        db: Session,
        user_id: UUID,
        question: str,
        conversation_id: UUID | None = None,
        created_by=None,
    ):
        question = question.strip()
        if not question:
            raise ValueError("Question cannot be empty")

        if not self.users.get_by_id(db, user_id):
            raise LookupError("User not found")

        history: list[dict] = []
        if conversation_id:
            conversation = self.conversations.get_by_id(db, conversation_id)
            if not conversation or conversation.user_id != user_id:
                raise LookupError("Conversation not found")

            history = [
                {"role": m.message_role, "content": m.message}
                for m in self.messages.get_recent(db, conversation_id, HISTORY_LIMIT)
            ]
        else:
            conversation = Conversation(
                user_id=user_id,
                title=self._generate_title(question),
                adh_created_by=created_by,
            )

        asked_at = datetime.now(timezone.utc)
        answer = self.llm.ask_agent(history + [{"role": "user", "content": question}])
        answered_at = datetime.now(timezone.utc)

        # Persist only after the LLM succeeds so failures leave no partial data.
        try:
            if not conversation_id:
                self.conversations.create(db, conversation)

            self.messages.create(db, Message(
                conversation_id=conversation.id,
                message_role="user",
                message=question,
                adh_created_date=asked_at,
                adh_created_by=created_by,
            ))
            self.messages.create(db, Message(
                conversation_id=conversation.id,
                message_role="assistant",
                message=answer,
                adh_created_date=answered_at,
                adh_created_by=created_by,
            ))
            db.commit()
        except Exception:
            db.rollback()
            raise

        return conversation, answer

    def _generate_title(self, question: str) -> str:
        try:
            title = self.llm.ask_agent(
                [
                    {"role": "system", "content": TITLE_PROMPT},
                    {"role": "user", "content": question},
                ],
                approve_tools=False,
            )
        except LLMServiceError:
            title = question

        title = title.strip().strip('"').strip()
        return (title or question)[:TITLE_MAX_LENGTH]
