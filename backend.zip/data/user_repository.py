from sqlalchemy import select
from sqlalchemy.orm import Session

from models import User


class UserRepository:

    def get_by_id(self, db: Session, user_id):
        return db.get(User, user_id)

    def get_by_email(self, db: Session, email: str):
        return db.scalar(
            select(User).where(User.email == email)
        )

    def get_all(self, db: Session):
        return db.scalars(
            select(User).order_by(User.adh_created_date.desc())
        ).all()

    def create(self, db: Session, user: User):
        db.add(user)
        db.flush()
        return user