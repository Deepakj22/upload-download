from sqlalchemy import select
from sqlalchemy.orm import Session

from models import Conversation


class ConversationRepository:

    def get_by_id(self, db: Session, conversation_id):
        return db.get(Conversation, conversation_id)

    def get_by_user(self, db: Session, user_id):
        return db.scalars(
            select(Conversation)
            .where(Conversation.user_id == user_id)
            .order_by(Conversation.adh_created_date.desc())
        ).all()

    def create(self, db: Session, conversation: Conversation):
        db.add(conversation)
        db.flush()
        return conversation

    def delete(self, db: Session, conversation: Conversation):
        db.delete(conversation)
        db.flush()