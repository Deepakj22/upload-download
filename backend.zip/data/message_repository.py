from sqlalchemy import select
from sqlalchemy.orm import Session

from models import Message


class MessageRepository:

    def get_by_conversation(self, db: Session, conversation_id):
        return db.scalars(
            select(Message)
            .where(Message.conversation_id == conversation_id)
            .order_by(
                Message.adh_created_date.asc(),
                Message.id.asc(),
            )
        ).all()

    def get_recent(self, db: Session, conversation_id, limit: int):
        recent = db.scalars(
            select(Message)
            .where(Message.conversation_id == conversation_id)
            .order_by(
                Message.adh_created_date.desc(),
                Message.id.desc(),
            )
            .limit(limit)
        ).all()
        return list(reversed(recent))

    def create(self, db: Session, message: Message):
        db.add(message)
        db.flush()
        return message