import logging
import os

from dotenv import load_dotenv
from openai import OpenAI, OpenAIError

load_dotenv()

logger = logging.getLogger(__name__)

MAX_APPROVAL_ROUNDS = 5


class LLMServiceError(Exception):
    pass


def _field(item, name):
    return item.get(name) if isinstance(item, dict) else getattr(item, name, None)


def _to_input(item) -> dict:
    return item if isinstance(item, dict) else item.model_dump(exclude_none=True)


def _extract_answer(response) -> str:
    # Supervisor agents emit intermediate items (tool calls, sub-agent messages); the final message is the answer.
    for item in reversed(response.output or []):
        if getattr(item, "type", None) != "message":
            continue
        text = "".join(
            getattr(part, "text", "") or ""
            for part in getattr(item, "content", None) or []
            if getattr(part, "type", None) == "output_text"
        ).strip()
        if text:
            return text

    return (getattr(response, "output_text", "") or "").strip()


class LLMClient:

    def __init__(self):
        api_key = os.getenv("DATABRICKS_TOKEN")
        agent_base_url = os.getenv("DATABRICKS_AGENT_BASE_URL")
        self.agent_model = os.getenv("DATABRICKS_AGENT_MODEL")

        if not api_key or not agent_base_url or not self.agent_model:
            raise RuntimeError(
                "DATABRICKS_TOKEN, DATABRICKS_AGENT_BASE_URL and "
                "DATABRICKS_AGENT_MODEL must be configured"
            )

        self.agent = OpenAI(api_key=api_key, base_url=agent_base_url)

    def ask_agent(self, messages: list[dict], approve_tools: bool = True) -> str:
        conversation: list[dict] = list(messages)

        for _ in range(MAX_APPROVAL_ROUNDS + 1):
            try:
                response = self.agent.responses.create(
                    model=self.agent_model,
                    input=conversation,
                )
            except OpenAIError as exc:
                raise LLMServiceError("Agent request failed") from exc

            output = response.output or []
            approvals = [
                item for item in output
                if _field(item, "type") == "mcp_approval_request"
            ]
            if not approvals:
                break
            if not approve_tools:
                raise LLMServiceError("Agent requested a tool during title generation")

            # Endpoint is stateless: resend prior output plus approvals to resume the run.
            conversation.extend(_to_input(item) for item in output)
            for request in approvals:
                logger.info(
                    "Auto-approving MCP tool call: server=%s tool=%s id=%s",
                    _field(request, "server_label"),
                    _field(request, "name"),
                    _field(request, "id"),
                )
                conversation.append({
                    "type": "mcp_approval_response",
                    "approval_request_id": _field(request, "id"),
                    "approve": True,
                })
        else:
            raise LLMServiceError("Agent exceeded the maximum number of tool approvals")

        answer = _extract_answer(response)
        if not answer:
            raise LLMServiceError("Agent returned an empty response")

        return answer

