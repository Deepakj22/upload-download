def main() -> None:
    print("Hello from adh-knowledge-api!")
