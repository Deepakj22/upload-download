import os

from dotenv import load_dotenv
from fastapi import HTTPException, Security
from fastapi_azure_auth.auth import (
    SingleTenantAzureAuthorizationCodeBearer,
)
from fastapi_azure_auth.user import User as AzureUser

load_dotenv()

TENANT_ID = os.environ["ENTRA_TENANT_ID"]
CLIENT_ID = os.environ["ENTRA_API_CLIENT_ID"]

API_SCOPE = f"api://{CLIENT_ID}/access_as_user"
REQUIRED_APP_ROLE = os.getenv("ENTRA_REQUIRED_APP_ROLE", "Knowledge.Access")

# azure_scheme = SingleTenantAzureAuthorizationCodeBearer(
#     app_client_id=CLIENT_ID,
#     tenant_id=TENANT_ID,
#     scopes={
#         API_SCOPE: "Access ADH Knowledge API",
#     },
# )
azure_scheme = SingleTenantAzureAuthorizationCodeBearer(
    app_client_id=CLIENT_ID,
    tenant_id=TENANT_ID,
    scopes={
        f"api://{CLIENT_ID}/access_as_user": "Access ADH Knowledge API",
    },
)


def require_knowledge_access(
    user: AzureUser = Security(azure_scheme, scopes=["access_as_user"]),
) -> AzureUser:
    roles = user.claims.get("roles", [])
    if isinstance(roles, str):
        roles = [roles]

    if REQUIRED_APP_ROLE not in roles:
        raise HTTPException(status_code=403, detail="Access denied")

    return user