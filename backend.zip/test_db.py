
from sqlalchemy import text
from database import engine

try:
    with engine.connect() as connection:
        result = connection.execute(
            text("SELECT current_database(), version()")
        )
        database_name, version = result.fetchone()

        print("PostgreSQL connection successful!")
        print("Database:", database_name)
        print("Version:", version)

except Exception as exc:
    print("PostgreSQL connection failed!")
    print("Error:", exc)
