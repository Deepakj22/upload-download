from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database import get_db
from schemas import MessageCreate, MessageResponse
from services.message_service import MessageService

router = APIRouter(prefix="/api/conversations", tags=["Messages"])
service = MessageService()


@router.post(
    "/{conversation_id}/messages",
    response_model=MessageResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_message(
    conversation_id: UUID,
    data: MessageCreate,
    db: Session = Depends(get_db),
):
    try:
        return service.create_message(
            db,
            conversation_id,
            data.message_role,
            data.message,
            data.adh_created_by,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get(
    "/{conversation_id}/messages",
    response_model=list[MessageResponse],
)
def get_messages(
    conversation_id: UUID,
    db: Session = Depends(get_db),
):
    try:
        return service.get_messages(db, conversation_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))