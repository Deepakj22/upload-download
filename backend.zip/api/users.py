from fastapi import APIRouter, Depends, HTTPException, Security, status
from fastapi_azure_auth.user import User as AzureUser
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from auth import azure_scheme
from database import get_db
from schemas import UserCreate, UserResponse
from services.user_service import UserService

router = APIRouter(prefix="/api/users", tags=["Users"])
service = UserService()


@router.post(
    "",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_user(data: UserCreate, db: Session = Depends(get_db)):
    try:
        return service.create_user(
            db,
            str(data.email),
            data.adh_created_by,
            data.profile_name,
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except IntegrityError:
        raise HTTPException(status_code=409, detail="Email already exists")


@router.get("", response_model=list[UserResponse])
def get_users(db: Session = Depends(get_db)):
    return service.get_users(db)


@router.post("/me", response_model=UserResponse)
def register_current_user(
    db: Session = Depends(get_db),
    token_user: AzureUser = Security(azure_scheme, scopes=["access_as_user"]),
):
    claims = token_user.claims
    email = (
        claims.get("email")
        or claims.get("preferred_username")
        or claims.get("upn")
    )
    if not email:
        raise HTTPException(status_code=400, detail="Email claim missing in token")

    profile_name = claims.get("name")

    try:
        return service.get_or_create_user(db, email, email, profile_name)
    except IntegrityError:
        # Concurrent first login created the user; fetch it.
        return service.get_or_create_user(db, email, email, profile_name)