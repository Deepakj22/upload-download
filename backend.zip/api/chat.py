from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from data.llm_client import LLMServiceError
from database import get_db
from schemas import ChatRequest, ChatResponse
from services.chat_service import ChatService

router = APIRouter(prefix="/api", tags=["Chat"])
service = ChatService()


@router.post(
    "/users/{user_id}/chat",
    response_model=ChatResponse,
)
def ask_question(
    user_id: UUID,
    data: ChatRequest,
    db: Session = Depends(get_db),
):
    try:
        conversation, answer = service.ask(
            db,
            user_id,
            data.question,
            data.conversation_id,
            data.adh_created_by,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except LLMServiceError as exc:
        raise HTTPException(status_code=502, detail=str(exc))

    return ChatResponse(
        conversation_id=conversation.id,
        title=conversation.title,
        answer=answer,
    )
