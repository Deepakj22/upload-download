from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database import get_db
from schemas import ConversationCreate, ConversationResponse
from services.conversation_service import ConversationService

router = APIRouter(prefix="/api", tags=["Conversations"])
service = ConversationService()


@router.post(
    "/users/{user_id}/conversations",
    response_model=ConversationResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_conversation(
    user_id: UUID,
    data: ConversationCreate,
    db: Session = Depends(get_db),
):
    try:
        return service.create_conversation(
            db, user_id, data.title, data.adh_created_by
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get(
    "/users/{user_id}/conversations",
    response_model=list[ConversationResponse],
)
def get_conversations(user_id: UUID, db: Session = Depends(get_db)):
    try:
        return service.get_conversations(db, user_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.delete("/conversations/{conversation_id}", status_code=204)
def delete_conversation(
    conversation_id: UUID,
    db: Session = Depends(get_db),
):
    try:
        service.delete_conversation(db, conversation_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))